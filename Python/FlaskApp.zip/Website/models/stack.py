
class Stack():
    pass
