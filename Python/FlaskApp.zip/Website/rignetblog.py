from flask import Flask, render_template, url_for, request

# flask app object
app = Flask(__name__)

posts = [
    {
        'author': 'Michel van Eekhout',
        'title': 'Blog Post 1',
        'content': 'NO EDUCATION, everyone in Quarantined!',
        'date_posted': 'March 13, 2020'
    },
    {
        'author': 'Michel van Eekhout',
        'title': 'Blog Post 2',
        'content': '1.5 meter afstand houden!',
        'date_posted': 'April 27, 2020'
    }
]

# list of resources for our web server
myList = []


@app.route('/api/cal/add/<int:number>')
def add(number):
    # Store the number in the list
    myList.append(number)
    # return a success message
    return "the number has been added to stack!"
    

@app.route('/api/cal/show')
def show():
    return str(myList)


@app.route('/api/cal/addpost', methods=['POST'])
def addNumberWithPostReq():
    number = request.json.get('number')
    myList.append(number)
    print("the number in post req is: "+ str(number))
    return "the number in post req is: "+ str(number)


@app.route('/')
@app.route('/home')
def home():
    return render_template('home.html', posts=posts)


@app.route('/inventory')
def inventory():
    print("now we are here in the inventory end-point")
    return render_template('inventory.html', title='Inventory')


@app.route('/about')
def about():
    print("now we are here in the about end-point")
    return render_template('about.html', title='About')


@app.route('/login', methods =['GET', 'POST'])
def loginPage():
    if request.method == 'GET':
        print("this is a get request")
        return render_template('login.html')
    else:
        print("this is a post request")
        username = request.form["inputUsername"]
        email = request.form["inputEmail"]
        password = request.form["inputPassword"]
        return render_template('login.html', name=username, email=email)


@app.route('/register', methods =['GET', 'POST'])
def registerPage():
    if request.method == 'GET':
        print("this is a get request")
        return render_template('register.html')
    else:
        print("this is a post request")
        username = request.form["inputUsername"]
        email = request.form["inputEmail"]
        password = request.form["inputPassword"]
        return render_template('register.html', name=username, email=email)

if __name__ == '__main__':
    app.run(debug=True)